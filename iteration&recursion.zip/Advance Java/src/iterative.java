

public class iterative {
	private static void fibSeq(int number) {
	 int prev = 0;
	 int curr = 1;
	 
	 System.out.printf(prev + " " + curr + " ");
	 for(int i = 0; i < number; i++) {
		 int next = prev + curr;
		 prev = curr;
		 curr = next;
		 
		 System.out.printf(next + " ");
	 }
	}
	public static void main(String[] args) {
		System.out.printf("Fibonacci Series of 10 numbers: ");
		int seq = 8;
		fibSeq(seq);
		
	
}
}